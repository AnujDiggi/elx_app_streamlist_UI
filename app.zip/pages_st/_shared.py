"""Bits shared by every authenticated page: a small header strip + the
global CSS that the Streamlit-port screens lean on."""
from __future__ import annotations

import streamlit as st


# Manrope + Inter are loaded as graceful fallbacks for users who don't have
# the proprietary Electrolux Sans corporate font installed locally. These two
# match what the Flask templates load (see templates/base.html).
GLOBAL_CSS = """
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  /* Brand font: Electrolux Sans applied to every text-bearing element in
     the app (main view, sidebar nav, widgets, tooltips, dataframes).
     Material icons are explicitly excluded below so they keep rendering
     as glyphs, not as the literal text "dashboard"/"login"/etc. */
  html, body, [class*="st-"], [data-testid], button, input, textarea,
  select, label, p, span, div, h1, h2, h3, h4, h5, h6, li, a, code, td, th {
    font-family: 'Electrolux Sans', 'Manrope', 'Inter',
                 -apple-system, BlinkMacSystemFont, 'Segoe UI',
                 Roboto, Helvetica, Arial, sans-serif !important;
  }
  /* Keep icon fonts intact — these classes/testids ship with Streamlit's
     Material Symbols/Material Icons and depend on their own font-family. */
  .material-icons, .material-symbols-rounded, .material-symbols-outlined,
  [class*="material-symbols"], [class*="material-icons"],
  [data-testid="stIconMaterial"], span[translate="no"][class*="icon"] {
    font-family: 'Material Symbols Rounded', 'Material Icons',
                 'Material Symbols Outlined' !important;
  }
  [data-testid="stMetric"] {
    background: #fff;
    border: 1px solid #e6e8eb;
    border-radius: 12px;
    padding: 14px 16px;
  }
  .brand-row { display:flex; align-items:center; gap:10px; font-weight:700; }
  .live-chip {
    display:inline-flex; align-items:center; gap:8px;
    padding: 6px 12px; border-radius: 999px;
    background: #ecfdf5; color:#065f46; font-size: 13px;
  }
  .live-chip .dot {
    width: 8px; height: 8px; border-radius: 50%; background: #22c55e;
    display: inline-block;
  }
  .ctx-pill {
    display:inline-block; padding: 4px 10px; margin: 2px 4px 2px 0;
    background: #f1f5f9; border-radius: 999px; font-size: 12px;
  }
</style>
"""


def inject_global_css() -> None:
    st.markdown(GLOBAL_CSS, unsafe_allow_html=True)


def topbar(scope_label: str = "FR10 · EA1 · BC04") -> None:
    """Render the user / scope / sign-out strip at the top of an auth'd page.

    The page-to-page nav is handled by `st.navigation` in the sidebar, so this
    strip is intentionally lighter than templates/_topbar.html.
    """
    user = st.session_state.get("user")
    if user is None:
        return

    brand_col, scope_col, user_col, signout_col = st.columns([3, 3, 3, 1])
    brand_col.markdown(
        '<div class="brand-row">⚡ <span>Electrolux</span></div>',
        unsafe_allow_html=True,
    )
    scope_col.markdown(
        f'<div class="live-chip"><span class="dot"></span>{scope_label}</div>',
        unsafe_allow_html=True,
    )
    user_col.markdown(f'**{user["name"]}**  \n_{user["role"]}_')
    if signout_col.button("Sign out", key="signout_btn"):
        st.session_state.pop("user", None)
        st.rerun()
    st.divider()
