"""Streamlit port of templates/simulate.html.

Widget mapping matches the HTML annotations:
  context filters → st.selectbox    parameter groups → st.expander
  param fields    → st.number_input run simulation   → st.form_submit_button
  progress        → st.progress     alerts           → st.warning / st.success
"""
from __future__ import annotations

import streamlit as st

import db_st
from pages_st._shared import topbar


_STEP_ICON = {"done": "✅", "current": "🟦"}


def _render_context_bar(context: list[dict], live_label: str) -> None:
    cols = st.columns(len(context) + 1)
    for i, c in enumerate(context):
        cols[i].selectbox(c["key"], options=[c["value"]], index=0, key=f"sim_ctx_{i}")
    cols[-1].markdown(
        f'<div class="live-chip"><span class="dot"></span>{live_label}</div>',
        unsafe_allow_html=True,
    )


def _render_stepper(steps: list[dict]) -> None:
    cols = st.columns(len(steps))
    for i, (s, col) in enumerate(zip(steps, cols), start=1):
        icon = _STEP_ICON.get(s["state"] or "", "⚪")
        weight = "**" if s["state"] == "current" else ""
        col.markdown(f"{icon} {weight}{i}. {s['label']}{weight}")


def _render_param_groups(groups: list[dict]) -> dict[str, float]:
    """Render each group as an `st.expander` of `st.number_input` fields.

    Returns the dict of current field values keyed by field name (used purely
    so the page can be wired up later; for now the values come from the DB).
    """
    field_values: dict[str, float] = {}
    for g in groups:
        title = f'{g["icon"]}  {g["title"]}'
        tags = " ".join(f'`{t["text"]}`' for t in g["tags"])
        with st.expander(f"{title}  —  {tags}", expanded=g["expanded"]):
            st.caption(g["desc"])
            for f in g["fields"]:
                name_tags = " ".join(f'`{t["text"]}`' for t in f["name_tags"])
                st.markdown(f'**{f["name"]}**  {name_tags}')
                st.caption(f["desc"])
                col_in, col_suffix = st.columns([5, 1])
                # number_input accepts None for min/max/step → no bound.
                value = col_in.number_input(
                    label=f["name"],
                    value=float(f["value"]),
                    min_value=float(f["min"]) if f["min"] is not None else None,
                    max_value=float(f["max"]) if f["max"] is not None else None,
                    step=float(f["step"]) if f["step"] is not None else None,
                    key=f'sim_field_{g["title"]}_{f["name"]}',
                    label_visibility="collapsed",
                )
                col_suffix.markdown(f'<div style="padding-top:8px">{f["suffix"]}</div>',
                                    unsafe_allow_html=True)
                field_values[f["name"]] = value
    return field_values


def _render_impact_sidebar(data: dict) -> None:
    with st.container(border=True):
        st.markdown("##### Live impact preview")
        st.caption("⚡ Real-time")
        st.markdown(f"### {data['impact']['headline']}")
        st.caption(data["impact"]["sub"])
        st.caption(data["impact"]["note"])
        st.divider()
        for r in data["impact"]["rows"]:
            color = {"red": "🟥", "green": "🟩", "yellow": "🟨",
                     "blue": "🟦", "orange": "🟧"}.get(r["sq"], "⬜")
            cl, cr = st.columns([3, 2])
            cl.markdown(f'{color} {r["name"]}')
            cr.markdown(f'**{r["value"]}**')

    with st.container(border=True):
        head_l, head_r = st.columns([3, 2])
        head_l.markdown("##### Parameters status")
        head_r.markdown(f"_{data['status_summary']}_")
        for s in data["status_rows"]:
            cl, cr = st.columns([3, 2])
            cl.markdown(s["name"])
            if s["pill"] == "done":
                cr.success(s["pill_text"], icon="✅")
            else:
                cr.warning(s["pill_text"], icon="⏳")
        st.warning(data["warn_message"], icon="⚠️")

    with st.container(border=True):
        head_l, head_r = st.columns([3, 2])
        head_l.markdown("##### Databricks context")
        head_r.markdown(
            '<span class="live-chip"><span class="dot"></span>Live</span>',
            unsafe_allow_html=True,
        )
        for r in data["ctx_rows"]:
            cl, cr = st.columns([3, 2])
            cl.caption(r["label"])
            cr.markdown(f'**{r["value"]}**')


def render() -> None:
    topbar(scope_label="All Countries")
    data = db_st.get_simulate_data()

    _render_context_bar(data["context"], data["live_label"])
    st.divider()

    _render_stepper(data["steps"])
    st.divider()

    left, right = st.columns([3, 2], gap="large")

    with left:
        with st.container(border=True):
            hl, hr = st.columns([4, 1])
            hl.markdown(f"## {data['params_title']}")
            hl.caption(data["params_sub"])
            hr.success("Saved", icon="✅")

            st.markdown(
                "".join(f'<span class="ctx-pill">{p}</span>'
                        for p in data["context_pills"]),
                unsafe_allow_html=True,
            )
            st.write("")

            with st.form("sim_form", clear_on_submit=False):
                _render_param_groups(data["param_groups"])
                st.caption(data["expander_text"])

                st.markdown(f'**{data["progress"]["label"]}** — {data["progress"]["count"]}')
                st.progress(float(data["progress"]["pct"]) / 100)

                bl, br = st.columns(2)
                bl.form_submit_button("↺  Reset")
                br.form_submit_button("▶  Start simulation", type="primary",
                                      use_container_width=True)

    with right:
        _render_impact_sidebar(data)
