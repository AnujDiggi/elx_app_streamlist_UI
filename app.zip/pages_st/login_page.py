"""Streamlit port of templates/login.html.

Matches Flask `/login` + `/sso`:
- email + password authenticated via `db_st.authenticate`
- SSO button shows the same info flash the Flask `/sso` route produces
  ("Databricks SSO is not configured in this build.")
"""
from __future__ import annotations

import streamlit as st

import db_st


PREFILL_EMAIL = "nanda.kishore@electrolux.com"


def render() -> None:
    left, right = st.columns([1, 1], gap="large")

    # ---- Left marketing panel ----
    with left:
        st.markdown("# ⚡ Electrolux")
        st.markdown("### Smarter logistics decisions, faster.")
        st.write(
            "The EMEA Logistics Cost Simulator replaces fragmented Excel models "
            "with a centralised, interactive simulation platform."
        )

        st.markdown(
            "<div>"
            '<span class="ctx-pill">📊 Real-time cost simulation</span>'
            '<span class="ctx-pill">🔒 Secure version control</span>'
            '<span class="ctx-pill">📊 Power BI integration</span>'
            '<span class="ctx-pill">🌍 4 EMEA countries</span>'
            "</div>",
            unsafe_allow_html=True,
        )

        st.write("")
        s1, s2, s3, s4 = st.columns(4)
        s1.metric("Records simulated", "6M+")
        s2.metric("Concurrent users", "30")
        s3.metric("EMEA countries", "4")
        s4.metric("Current FADP", "BC04")

    # ---- Right login card ----
    with right:
        with st.container(border=True):
            st.markdown("### Welcome back")
            st.caption("Sign in to Logistics Cost Simulator")

            if st.button("⬢  Continue with Databricks SSO", use_container_width=True):
                st.info("Databricks SSO is not configured in this build.")

            st.markdown("---")
            st.caption("or sign in with credentials")

            with st.form("login_form", clear_on_submit=False):
                email = st.text_input("Email Address", value=PREFILL_EMAIL, autocomplete="email")
                password = st.text_input("Password", type="password", autocomplete="current-password")
                submitted = st.form_submit_button("Sign in", type="primary", use_container_width=True)

            if submitted:
                user = db_st.authenticate((email or "").strip().lower(), password or "")
                if user is None:
                    st.error("Invalid email or password.")
                else:
                    st.session_state["user"] = user
                    st.rerun()

            st.caption(
                "Access is managed by Databricks workspace. "
                "Contact your IT admin if you cannot sign in."
            )

        st.caption("LCS v1.0  ·  EMEA Supply Chain  ·  Electrolux Group")
