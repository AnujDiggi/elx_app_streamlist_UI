"""Streamlit port of templates/dashboard.html.

Same data contract as Flask `/dashboard` (db.get_dashboard_data), same per-section
widget mapping shown as badges in the HTML: st.selectbox, st.slider, st.metric,
st.dataframe, st.progress, st.warning/info, st.download_button.
"""
from __future__ import annotations

import io
from typing import Literal, cast

import pandas as pd
import streamlit as st

import db_st
from pages_st._shared import topbar


DeltaColor = Literal["normal", "inverse", "off"]


def _delta_color(badge_arrow: str | None) -> DeltaColor:
    # Cost dashboard: up = bad (red), down = good (green); Streamlit's default
    # "normal" colors + green and - red, so flip with "inverse".
    if badge_arrow is None:
        return "off"
    return "inverse"


def render() -> None:
    topbar()

    user = st.session_state["user"]
    data = db_st.get_dashboard_data(user["name"])

    # ----- Filters bar — st.selectbox + st.slider -----
    # Matches templates/dashboard.html <section class="filters">: a single
    # bottom-aligned row with "Filters:" label, every filter selectbox, the
    # sliders, a live-data chip, and the Start simulation CTA at the right.
    n_filters = len(data["filters"])
    n_sliders = len(data["sliders"])
    label_ratio = [0.5]
    filter_ratios = [1.0] * n_filters
    slider_ratios = [1.4] * n_sliders
    tail_ratios = [1.2, 1.4]  # live chip, button
    cols = st.columns(
        label_ratio + filter_ratios + slider_ratios + tail_ratios,
        vertical_alignment="bottom",
    )

    cols[0].markdown("**Filters**")

    for i, f in enumerate(data["filters"]):
        cols[1 + i].selectbox(
            f["key"], options=[f["value"]], index=0, key=f"filter_{i}"
        )

    for j, s in enumerate(data["sliders"]):
        # `format` is sprintf-style on the frontend — escape literal % as %%.
        suffix_escaped = (s["suffix"] or "").replace("%", "%%")
        cols[1 + n_filters + j].slider(
            f'{s["key"]}',
            min_value=int(s["min"]),
            max_value=int(s["max"]),
            value=int(s["value"]),
            step=1,
            format=f"%d{suffix_escaped}",
            key=f"slider_{j}",
        )

    cols[-2].markdown(
        f'<div class="live-chip"><span class="dot"></span>{data["live_label"]}</div>',
        unsafe_allow_html=True,
    )
    if cols[-1].button("▶  Start simulation", type="primary", use_container_width=True, key="dash_start_sim"):
        st.switch_page(st.session_state["_pages"]["simulate"])

    # ----- Hero banner -----
    with st.container(border=True):
        head_col, *stat_cols, btn_col = st.columns(
            [4] + [1] * len(data["hero"]["stats"]) + [1]
        )
        with head_col:
            st.caption(data["hero"]["tag"])
            st.subheader(data["hero"]["title"])
            st.caption(data["hero"]["sub"])
        for stat, col in zip(data["hero"]["stats"], stat_cols):
            col.metric(label=stat["label"], value=stat["num"])
        btn_col.write("")
        if btn_col.button("Open simulator  →", use_container_width=True, key="dash_open_sim"):
            st.switch_page(st.session_state["_pages"]["simulate"])

    # ----- KPI cards — st.metric -----
    kpi_cols = st.columns(len(data["kpis"]))
    for kpi, col in zip(data["kpis"], kpi_cols):
        col.metric(
            label=kpi["label"],
            value=kpi["value"],
            delta=f'{kpi["badge_text"]} · {kpi["meta"]}',
            delta_color=cast(DeltaColor, _delta_color(kpi["badge_arrow"])),
        )

    # ----- Simulation result table — st.dataframe -----
    table_df = pd.DataFrame(
        [
            {
                "Cost category":    r["category"],
                "Bucket":           r["bucket"],
                "Actual (EUR)":     r["actual"],
                "Forecast (EUR)":   r["forecast"],
                "Simulation (EUR)": r["simulation"],
                "Δ vs baseline":    r["delta_text"],
                "Δ %":              r["delta_pct"],
                "Source":           r["source"],
                "Status":           r["status"],
            }
            for r in data["table"]["rows"]
        ]
    )

    excel_buf = io.BytesIO()
    with pd.ExcelWriter(excel_buf, engine="openpyxl") as writer:  # pyright: ignore[reportArgumentType]
        table_df.to_excel(writer, index=False, sheet_name="Simulation")

    head_left, head_right_a, head_right_b = st.columns([5, 1, 1], vertical_alignment="center")
    with head_left:
        st.markdown(f"### {data['table']['title']}  ·  _From Databricks_")
        st.caption(data["table"]["meta"])
    head_right_a.download_button(
        "⬇  Export Excel",
        data=excel_buf.getvalue(),
        file_name="simulation_result.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True,
    )
    head_right_b.button("✓  Submit", type="primary", key="dash_submit",
                        use_container_width=True)

    st.dataframe(table_df, use_container_width=True, hide_index=True)

    pag = data["table"]["pagination"]
    st.caption(f"Showing **{pag['showing']} of {pag['total']}** records")

    # ----- Bottom panels — Country status / Deadlines / Activity -----
    panel_country, panel_deadline, panel_activity = st.columns(3)

    with panel_country:
        st.markdown("##### Country status — EA1 BC04")
        st.caption("st.metric")
        for c in data["countries"]:
            icon = {"ok": "🟢", "warn": "🟡", "danger": "🔴"}.get(c["status"], "⚪")
            st.write(
                f'{c["flag"]} **{c["code"]} — {c["name"]}**  ·  {icon}  ·  **{c["pct"]}%**'
            )
            st.progress(c["bar_width"] / 100)

    with panel_deadline:
        st.markdown("##### Upcoming deadlines")
        st.caption("st.warning")
        for d in data["deadlines"]:
            body = (
                f'**{d["day"]} {d["month"]}** — {d["title"]}  \n'
                f'{d["meta"]}  ·  _{d["chip"]}_'
            )
            if d["urgent"]:
                st.warning(body, icon="⚠️")
            else:
                st.info(body, icon="🗓️")

    with panel_activity:
        st.markdown("##### Recent activity")
        st.caption("View all →")
        for a in data["activities"]:
            icon = {"check": "✅", "download": "⬇️", "bolt": "⚡"}.get(a["icon"], "•")
            warn = "  ⚠️ urgent" if a.get("meta_warn") else ""
            st.write(f'{icon}  **{a["title"]}**  \n_{a["meta"]}{warn}_')
