"""Multipage Streamlit entry point for nanda_app.

Run with: `streamlit run streamlit_app.py`

Mirrors the Flask app's surface:
  /login   → Sign in (email/password + SSO info banner)
  /        → redirect to /dashboard or /login depending on auth
  /dashboard → Dashboard
  /simulate  → Simulate
  /admin     → Admin (admin-only, hidden from sidebar for non-admins)
  /logout    → "Sign out" button in the topbar

Auth state lives in `st.session_state["user"]`; pages re-read it on every run.
"""
from __future__ import annotations

import streamlit as st

from pages_st import admin_page, dashboard_page, login_page, simulate_page
from pages_st._shared import inject_global_css

st.set_page_config(
    page_title="Logistics Cost Simulator · Electrolux",
    page_icon="📊",
    layout="wide",
)
inject_global_css()

user = st.session_state.get("user")

if user is None:
    # Single hidden-nav page until the user signs in.
    nav = st.navigation(
        [st.Page(login_page.render, title="Sign in", url_path="login",
                 icon=":material/login:")],
        position="hidden",
    )
else:
    dashboard = st.Page(dashboard_page.render, title="Dashboard",
                        url_path="dashboard", icon=":material/dashboard:",
                        default=True)
    simulate  = st.Page(simulate_page.render,  title="Simulate",
                        url_path="simulate",  icon=":material/science:")
    pages = [dashboard, simulate]
    if user["is_admin"]:
        pages.append(st.Page(admin_page.render, title="Admin",
                             url_path="admin",
                             icon=":material/admin_panel_settings:"))

    # Expose page handles so dashboard buttons can `st.switch_page(...)`.
    st.session_state["_pages"] = {"dashboard": dashboard, "simulate": simulate}

    nav = st.navigation(pages)

nav.run()
